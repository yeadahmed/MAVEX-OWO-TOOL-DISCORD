#!/usr/bin/env python3
"""
MAVEX OWO TOOL - A reference tool for OWO bot game commands and strategies
"""
import os
import sys
import time
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.layout import Layout
from rich.live import Live
from rich.prompt import Prompt
from ui import create_header, create_layout, display_main_menu, handle_menu_selection
from utils import clear_screen

# Flask app for the web interface
from flask import Flask, render_template_string

# Create the Flask app
app = Flask(__name__)

@app.route('/')
def index():
    html = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>MAVEX OWO TOOL</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css" rel="stylesheet">
        <style>
            body {
                background-color: #1e1e2e;
                color: #cdd6f4;
                padding: 2rem;
            }
            .container {
                max-width: 800px;
                margin: 0 auto;
            }
            .card {
                background-color: #313244;
                border: 1px solid #45475a;
                border-radius: 8px;
                margin-bottom: 1.5rem;
            }
            .card-header {
                background-color: #45475a;
                color: #cdd6f4;
                font-weight: bold;
                padding: 1rem;
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
            }
            .card-body {
                padding: 1.5rem;
            }
            .feature-list {
                list-style-type: none;
                padding-left: 0;
            }
            .feature-list li {
                margin-bottom: 0.5rem;
                padding-left: 1.5rem;
                position: relative;
            }
            .feature-list li:before {
                content: "✓";
                color: #a6e3a1;
                position: absolute;
                left: 0;
            }
            .text-success {
                color: #a6e3a1;
            }
            .text-info {
                color: #89b4fa;
            }
            .text-warning {
                color: #f9e2af;
            }
            .btn-primary {
                background-color: #89b4fa;
                border-color: #89b4fa;
            }
            .btn-primary:hover {
                background-color: #74c7ec;
                border-color: #74c7ec;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1 class="text-center mb-4">🤖 MAVEX OWO TOOL</h1>
            <p class="lead text-center mb-5">A powerful tool for optimizing your OWO bot experience</p>
            
            <div class="card">
                <div class="card-header">
                    About MAVEX OWO TOOL
                </div>
                <div class="card-body">
                    <p>MAVEX OWO TOOL is a comprehensive Discord bot automation tool designed to enhance OWO game interactions through intelligent command management and strategic optimization.</p>
                    <p>The main application is terminal-based, providing a rich interactive experience with detailed statistics, strategies, and automation features.</p>
                    <p class="mt-4"><strong>To use MAVEX OWO TOOL:</strong> Run the "run_owo_tool" workflow from the Replit interface.</p>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    Key Features
                </div>
                <div class="card-body">
                    <ul class="feature-list">
                        <li><span class="text-info">Discord Token Handling</span>: Secure token processing with comprehensive validation</li>
                        <li><span class="text-info">Automated Command Execution</span>: Intelligent command scheduling with optimal timing</li>
                        <li><span class="text-info">Dynamic Cooldown Management</span>: Adaptive cooldown handling to maximize efficiency</li>
                        <li><span class="text-info">Advanced Error Handling</span>: Robust recovery from API errors and connection issues</li>
                        <li><span class="text-info">Live Statistics</span>: Real-time performance tracking with detailed metrics</li>
                        <li><span class="text-info">Game Strategy Optimization</span>: AI-powered gameplay recommendations</li>
                    </ul>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    Recent Updates
                </div>
                <div class="card-body">
                    <ul class="feature-list">
                        <li><span class="text-success">Enhanced token validation</span> supporting multiple token formats</li>
                        <li><span class="text-success">Improved error handling</span> for Discord API responses</li>
                        <li><span class="text-success">Added fallback mechanisms</span> for connection issues</li>
                        <li><span class="text-success">Enhanced security</span> with obfuscated token display</li>
                        <li><span class="text-success">Rate limit protection</span> to prevent account flagging</li>
                    </ul>
                </div>
            </div>
            
            <div class="text-center mt-5">
                <a href="#" class="btn btn-primary me-2">Access Terminal Tool</a>
                <a href="#" class="btn btn-outline-light">View Documentation</a>
            </div>
        </div>
    </body>
    </html>
    """
    return render_template_string(html)

def main():
    """Main application entry point."""
    console = Console()
    clear_screen()
    
    # Create layout
    layout = create_layout()
    
    # Display welcome message
    console.print(Panel(
        Text.from_markup(
            "[bold green]Welcome to MAVEX OWO TOOL![/bold green]\n\n"
            "This tool provides information and strategies to optimize your profits "
            "with OWO bot games. Browse through different commands, learn strategies, "
            "and improve your win rates."
        ),
        title="Welcome",
        border_style="blue"
    ))
    console.print("Press Enter to continue...")
    try:
        input()
    except EOFError:
        # Continue if running in a non-interactive environment
        pass
    
    # Main application loop
    while True:
        clear_screen()
        # Display the header
        console.print(create_header())
        # Display the menu directly without using Live
        console.print(display_main_menu())
        
        try:
            # Show choices explicitly for clarity
            console.print("[bold cyan]Enter your choice (1-9, P for Platform Guide, A for About, or 0 to exit):[/bold cyan]")
            choice = input("> ").strip().lower()
            
            if choice == "0":
                break
            elif choice in ["1", "2", "3", "4", "5", "6", "7", "8", "9", "p", "a", "0"]:
                result = handle_menu_selection(choice)
                if result:
                    clear_screen()
                    console.print(create_header())
                    console.print(result)
                    console.print("\nPress Enter to return to the main menu...")
                    try:
                        input()
                    except EOFError:
                        # Continue if running in a non-interactive environment
                        time.sleep(2)
            else:
                console.print(Panel(
                    "Invalid choice. Please enter a number from 1-9, P for Platform Guide, A for About, or 0 to exit.",
                    title="Error",
                    border_style="red"
                ))
                time.sleep(2)
                
        except KeyboardInterrupt:
            break
        except EOFError:
            # Handle EOFError in non-interactive environments
            time.sleep(2)
            break
        except Exception as e:
            console.print(Panel(
                f"An error occurred: {str(e)}",
                title="Error",
                border_style="red"
            ))
            time.sleep(2)
    
    # Exit message
    clear_screen()
    console.print(Panel(
        "Thank you for using MAVEX OWO TOOL!",
        title="Goodbye",
        border_style="green"
    ))

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nExiting...")
        sys.exit(0)
