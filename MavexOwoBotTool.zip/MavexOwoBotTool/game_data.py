"""
Game data and information for the MAVEX OWO TOOL
"""

def get_command_details():
    """Get detailed information about OWO bot commands."""
    return [
        {
            "command": "owo cf",
            "description": "Coinflip game where you bet on heads or tails",
            "usage": "owo cf [amount] [h/t]"
        },
        {
            "command": "owo s",
            "description": "Slots game with various combinations and payouts",
            "usage": "owo s [amount]"
        },
        {
            "command": "owo b",
            "description": "Blackjack game where you try to get closer to 21 than the dealer",
            "usage": "owo b [amount]"
        },
        {
            "command": "owo h",
            "description": "Hunt animals for random rewards",
            "usage": "owo h"
        },
        {
            "command": "owo battle",
            "description": "Battle with your pets against others",
            "usage": "owo battle"
        },
        {
            "command": "owo predict",
            "description": "Predicts the most profitable commands based on current win rates",
            "usage": "owo predict [amount]"
        },
        {
            "command": "owo hunt",
            "description": "Alias for 'owo h'",
            "usage": "owo hunt"
        },
        {
            "command": "owo flip",
            "description": "Alias for 'owo cf'",
            "usage": "owo flip [amount] [h/t]"
        },
        {
            "command": "owo slots",
            "description": "Alias for 'owo s'",
            "usage": "owo slots [amount]"
        },
        {
            "command": "owo blackjack",
            "description": "Alias for 'owo b'",
            "usage": "owo blackjack [amount]"
        },
        {
            "command": "owo daily",
            "description": "Claim daily rewards",
            "usage": "owo daily"
        },
        {
            "command": "owo cash",
            "description": "Check your current balance",
            "usage": "owo cash [@user]"
        },
        {
            "command": "owo give",
            "description": "Give currency to another user",
            "usage": "owo give [amount] [@user]"
        },
        {
            "command": "owo quest",
            "description": "Check available quests for rewards",
            "usage": "owo quest"
        },
    ]

def get_game_guides():
    """Get detailed guides for OWO bot games."""
    return [
        {
            "name": "owo cf (Coinflip)",
            "description": "A simple heads or tails game with a 50% base win chance",
            "guide": "The coinflip game is the simplest gambling game in OWO bot. You bet an amount and choose either heads (h) or tails (t). If your guess is correct, you win the same amount you bet. If wrong, you lose your bet.\n\nThe win multiplier is 2x, meaning if you bet 100 coins and win, you'll receive 200 coins (your original 100 plus 100 more).",
            "tips": "Since this is a 50/50 game with equal payout, it has a theoretical 0% expected value over time. However, you can optimize your profits by only playing when you have coinflip-related quests or when you have buffs active that increase your gambling gains."
        },
        {
            "name": "owo s (Slots)",
            "description": "A slots game with multiple winning combinations",
            "guide": "The slots game has multiple winning combinations with different payouts:\n- 🍇 🍇 🍇 = 10x multiplier\n- 🍊 🍊 🍊 = 20x multiplier\n- 🍈 🍈 🍈 = 30x multiplier\n- 🍒 🍒 🍒 = 40x multiplier\n- 🍍 🍍 🍍 = 50x multiplier\n- 🍇 🍇 ⚔️ = 2x multiplier\n- 🍊 🍊 ⚔️ = 2x multiplier\n- 🍈 🍈 ⚔️ = 2x multiplier\n\nAny other combination results in a loss.",
            "tips": "Slots has a negative expected value of approximately -30% (house edge), making it the least profitable game for long-term play. Only use slots when completing quests or when you have significant buff multipliers active."
        },
        {
            "name": "owo h (Hunt)",
            "description": "Hunt for animals to earn random rewards",
            "guide": "Hunt is not a gambling game but a core command for earning currency. When you use this command, you'll hunt random animals worth different amounts of currency. Occasionally, you'll find special or rare animals worth more.\n\nHunt can be used every 10 seconds. For optimal currency gain, use it as often as possible.",
            "tips": "Set up a timer or reminder to use this command regularly. It's one of the most consistent ways to earn currency with OWO bot. Pair it with the 'owo battle' command for maximum efficiency."
        },
        {
            "name": "owo b (Blackjack)",
            "description": "A blackjack game where you aim to get closer to 21 than the dealer",
            "guide": "Blackjack follows standard rules:\n1. You and the dealer are dealt cards\n2. You can 'hit' to draw more cards or 'stand' to keep your current hand\n3. The goal is to get as close to 21 as possible without going over\n4. Face cards are worth 10, Aces are worth 1 or 11\n5. If you win, you get a 2x payout\n\nOWO bot allows you to hit (h) or stand (s) when prompted during the game.",
            "tips": "Blackjack has the lowest house edge of all OWO gambling games (around 1-4% depending on your strategy). Always stand on 17+ and always hit on 11 or less. For 12-16, hit if the dealer shows 7 or higher, otherwise stand."
        },
        {
            "name": "owo battle",
            "description": "Battle with your pets against others",
            "guide": "Battle allows you to use your pets to fight other users' pets. You can earn weapons, experience for your pets, and sometimes currency.\n\nThis command can be used every 15 minutes. It's a key part of progressing in the pet system, which can later help with hunt efficiency and other bonuses.",
            "tips": "Always use the battle command when available. As your pets level up, they'll help you earn more from hunts and other activities. This creates a compounding effect that increases your overall earning potential."
        }
    ]

def get_strategy_details():
    """Get detailed information about profit optimization strategies."""
    return [
        {
            "name": "Hunt-Battle Cycle",
            "description": "Maximize passive income by optimizing hunt and battle commands usage",
            "implementation": "1. Set up a timer for 10-second intervals\n2. Use 'owo h' every 10 seconds\n3. Use 'owo battle' every 15 minutes\n4. Complete daily quests for bonus rewards\n5. Claim daily rewards with 'owo daily'",
            "outcome": "This strategy ensures you're earning the maximum possible passive income from non-gambling commands. With consistent execution, you can earn approximately 10,000-20,000 coins per hour."
        },
        {
            "name": "Blackjack Optimal Play",
            "description": "Use statistical optimal play for blackjack to minimize house edge",
            "implementation": "1. Always hit on 11 or lower\n2. Always stand on 17 or higher\n3. With 12-16: hit if dealer shows 7+, otherwise stand\n4. With soft 13-17 (Ace counted as 11): always hit\n5. With soft 18: stand if dealer shows 2, 7, or 8; otherwise hit\n6. With soft 19 or higher: always stand",
            "outcome": "By following optimal blackjack strategy, you can reduce the house edge to around 1-2%, making it the most profitable gambling game in OWO bot when you need to complete gambling quests."
        },
        {
            "name": "Quest Prioritization",
            "description": "Complete quests in order of profitability for maximum reward efficiency",
            "implementation": "1. Always accept and complete daily quests\n2. Prioritize quests in this order:\n   - Hunt/Battle quests (highest profit)\n   - Coinflip quests (neutral EV)\n   - Blackjack quests (slight negative EV)\n   - Slots quests (only if required, high negative EV)\n3. Save gambling activities for when you have active quests",
            "outcome": "By completing quests strategically, you can earn an additional 5,000-15,000 coins daily from quest rewards alone, significantly boosting your overall profit."
        },
        {
            "name": "Buff Optimization",
            "description": "Only engage in gambling when you have active buff multipliers",
            "implementation": "1. Track active buffs that increase gambling payouts\n2. Save larger bets for when you have gambling buffs active\n3. Focus on hunt/battle during no-buff periods\n4. When buffs are active, favor games in this order:\n   - Blackjack\n   - Coinflip\n   - Slots (only with high multipliers)",
            "outcome": "By gambling strategically during buff periods, you can significantly offset the house edge and potentially achieve positive expected value during these windows."
        }
    ]

def get_win_rate_analysis():
    """Get win rate analysis for OWO bot games."""
    return [
        {
            "game": "owo cf (Coinflip)",
            "base_rate": "50.00",
            "strategy_rate": "50.00",
            "notes": "True 50/50 chance, no strategy can improve odds"
        },
        {
            "game": "owo s (Slots)",
            "base_rate": "31.25",
            "strategy_rate": "31.25",
            "notes": "Fixed odds based on symbol combinations, no strategy impact"
        },
        {
            "game": "owo b (Blackjack)",
            "base_rate": "42.50",
            "strategy_rate": "48.50",
            "notes": "Optimal strategy significantly improves win rate"
        },
        {
            "game": "owo h (Hunt)",
            "base_rate": "100.00",
            "strategy_rate": "100.00",
            "notes": "Always provides rewards, value varies by animal found"
        },
        {
            "game": "owo battle",
            "base_rate": "50.00",
            "strategy_rate": "65.00",
            "notes": "Pet selection and team composition can improve win rate"
        }
    ]

def get_timing_strategies():
    """Get command timing strategies."""
    return [
        {
            "name": "Hunt Timing Optimization",
            "description": "Maximize the efficiency of the hunt command by timing it properly",
            "timing": "Use exactly every 10 seconds for maximum efficiency",
            "benefits": "Optimal timing can result in 360 hunts per hour (vs. 300 or fewer with suboptimal timing), increasing hourly profits by 15-20%"
        },
        {
            "name": "Battle Cycling",
            "description": "Ensure consistent battle command usage",
            "timing": "Use exactly every 15 minutes (900 seconds)",
            "benefits": "Adds approximately 1,000-3,000 additional coins per hour when combined with regular hunting"
        },
        {
            "name": "Daily Quest Synchronization",
            "description": "Align gambling activities with quest completion times",
            "timing": "Complete gambling only when you have active quests for that game type",
            "benefits": "Increases effective profit by offsetting gambling losses with quest rewards"
        },
        {
            "name": "Buff Window Gambling",
            "description": "Concentrate gambling during buff windows",
            "timing": "Only gamble significant amounts when you have active buffs or multipliers",
            "benefits": "Can turn negative expected value games into positive expected value during short windows"
        }
    ]

def get_coin_optimization():
    """Get coin optimization techniques."""
    return [
        {
            "name": "Bet Sizing Strategy",
            "description": "Optimize your bet sizes based on your bankroll and game type",
            "implementation": "1. For coinflip: Bet 1-5% of your bankroll per flip\n2. For blackjack: Bet 2-3% of your bankroll per hand\n3. For slots: Bet minimum amount (only for quests)\n4. Increase bet size only during buff periods\n5. Always maintain at least 60% of your peak bankroll as reserve",
            "results": "Proper bet sizing prevents ruin during variance downswings and maximizes growth during positive variance periods"
        },
        {
            "name": "Quest-to-Gambling Ratio",
            "description": "Balance gambling with quest completion for optimal profit",
            "implementation": "1. Calculate quest reward value\n2. Only gamble up to the point where expected losses equal 60-70% of quest rewards\n3. Focus on passive income (hunt/battle) once gambling quests are complete\n4. Reset strategy daily with new quests",
            "results": "This approach ensures that gambling is always net-positive when combined with quest rewards"
        },
        {
            "name": "Progressive Hunt Strategy",
            "description": "Reinvest earnings into pet upgrades to increase hunt efficiency",
            "implementation": "1. Allocate 20-30% of daily profits to pet upgrades\n2. Focus on weapons that increase hunt rewards\n3. Level up pets that provide hunting bonuses\n4. Maintain consistent hunt timing regardless of upgrading activity",
            "results": "Creates a compounding effect where daily hunt income gradually increases over time"
        },
        {
            "name": "Daily Reward Maximization",
            "description": "Ensure consistent claiming of time-based rewards",
            "implementation": "1. Claim daily rewards at the same time each day\n2. Complete all available quests before reset\n3. Use 'owo daily' command every 24 hours\n4. Track streak bonuses for additional rewards",
            "results": "Adds 5,000-10,000 guaranteed daily income regardless of gambling outcomes"
        }
    ]
