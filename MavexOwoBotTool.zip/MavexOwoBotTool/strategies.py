"""
Strategy and calculation functions for the MAVEX OWO TOOL
"""
import numpy as np

def calculate_expected_return(bet_amount, win_rate, win_multiplier, loss_multiplier=1.0):
    """
    Calculate the expected return per bet.
    
    Args:
        bet_amount (float): The amount being bet
        win_rate (float): Win rate as a percentage (0-100)
        win_multiplier (float): The multiplier applied when winning
        loss_multiplier (float): The multiplier applied when losing (default: 1.0)
        
    Returns:
        float: The expected return per bet
    """
    win_rate_decimal = win_rate / 100.0
    loss_rate = 1.0 - win_rate_decimal
    
    win_amount = bet_amount * win_multiplier
    loss_amount = bet_amount * loss_multiplier
    
    expected_return = (win_rate_decimal * win_amount) - (loss_rate * loss_amount)
    return expected_return

def get_profit_calculation():
    """
    Get profit calculation data for different games.
    """
    return [
        {
            "game": "owo cf (Coinflip)",
            "bet_amount": 100,
            "win_rate": 50.0,
            "win_multiplier": 1.0,
            "loss_multiplier": 1.0,
            "games_per_hour": 60  # Assuming 1 minute per game including typing and response time
        },
        {
            "game": "owo s (Slots)",
            "bet_amount": 100,
            "win_rate": 31.25,
            "win_multiplier": 2.0,  # Average multiplier considering all win conditions
            "loss_multiplier": 1.0,
            "games_per_hour": 60
        },
        {
            "game": "owo b (Blackjack)",
            "bet_amount": 100,
            "win_rate": 48.5,  # With optimal strategy
            "win_multiplier": 1.0,
            "loss_multiplier": 1.0,
            "games_per_hour": 30  # Takes longer due to multiple interactions
        },
        {
            "game": "owo h (Hunt)",
            "bet_amount": 0,  # No betting involved
            "win_rate": 100.0,
            "win_multiplier": 0.0,  # Not applicable
            "loss_multiplier": 0.0,  # Not applicable
            "games_per_hour": 360  # Every 10 seconds
        },
        {
            "game": "Hunt + Battle Combo",
            "bet_amount": 0,  # No betting involved
            "win_rate": 100.0,
            "win_multiplier": 0.0,  # Special calculation
            "loss_multiplier": 0.0,  # Special calculation
            "games_per_hour": 1  # Special calculation, represents hourly income
        }
    ]

def calculate_blackjack_optimal_move(player_total, dealer_upcard, has_soft_ace=False):
    """
    Calculate the optimal move in blackjack based on the player's total and dealer's upcard.
    
    Args:
        player_total (int): The player's current hand total
        dealer_upcard (int): The dealer's visible card (1=Ace, 11-13=J,Q,K)
        has_soft_ace (bool): Whether the player has an Ace counted as 11
        
    Returns:
        str: 'hit' or 'stand' as the optimal move
    """
    # Convert face cards to 10 for calculation
    if dealer_upcard > 10:
        dealer_upcard = 10
        
    # Handle Ace as 1 or 11
    if dealer_upcard == 1:
        dealer_upcard = 11
    
    # Basic strategy for soft hands (hands with an Ace counted as 11)
    if has_soft_ace:
        if player_total >= 19:
            return 'stand'
        elif player_total == 18:
            if dealer_upcard in [2, 7, 8]:
                return 'stand'
            else:
                return 'hit'
        else:  # 17 or less
            return 'hit'
    
    # Basic strategy for hard hands
    if player_total >= 17:
        return 'stand'
    elif player_total <= 11:
        return 'hit'
    elif player_total >= 12 and player_total <= 16:
        if dealer_upcard >= 7:
            return 'hit'
        else:
            return 'stand'
    
    # Default case (shouldn't reach here with valid inputs)
    return 'stand'

def simulate_blackjack_outcomes(num_simulations=10000):
    """
    Simulate blackjack outcomes to determine expected win rate with optimal strategy.
    
    Args:
        num_simulations (int): Number of hands to simulate
        
    Returns:
        dict: Statistics about win rates
    """
    np.random.seed(42)  # For reproducibility
    
    wins = 0
    losses = 0
    pushes = 0
    
    for _ in range(num_simulations):
        # Initialize a deck (simplified for simulation)
        deck = np.repeat(np.arange(1, 14), 4)  # 1=Ace, 11,12,13=J,Q,K
        np.random.shuffle(deck)
        
        # Deal initial cards
        player_hand = [deck[0], deck[2]]
        dealer_hand = [deck[1], deck[3]]
        next_card = 4
        
        # Calculate initial totals
        player_total = calculate_hand_total(player_hand)
        dealer_upcard = dealer_hand[0]
        
        # Player's turn
        has_soft_ace = has_usable_ace(player_hand)
        
        # Keep hitting until strategy says to stand
        while calculate_blackjack_optimal_move(player_total, dealer_upcard, has_soft_ace) == 'hit':
            player_hand.append(deck[next_card])
            next_card += 1
            player_total = calculate_hand_total(player_hand)
            has_soft_ace = has_usable_ace(player_hand)
            
            # Check if player busts
            if player_total > 21:
                break
        
        # If player didn't bust, dealer's turn
        dealer_total = calculate_hand_total(dealer_hand)
        if player_total <= 21:
            # Dealer hits until 17 or higher
            while dealer_total < 17:
                dealer_hand.append(deck[next_card])
                next_card += 1
                dealer_total = calculate_hand_total(dealer_hand)
        
        # Determine outcome
        if player_total > 21:
            losses += 1
        elif dealer_total > 21:
            wins += 1
        elif player_total > dealer_total:
            wins += 1
        elif player_total < dealer_total:
            losses += 1
        else:
            pushes += 1
    
    # Calculate statistics
    total_completed = wins + losses + pushes
    win_rate = (wins / total_completed) * 100
    loss_rate = (losses / total_completed) * 100
    push_rate = (pushes / total_completed) * 100
    
    return {
        'win_rate': win_rate,
        'loss_rate': loss_rate,
        'push_rate': push_rate,
        'total_hands': total_completed
    }

def calculate_hand_total(hand):
    """
    Calculate the total value of a blackjack hand, accounting for Aces.
    
    Args:
        hand (list): List of card values (1=Ace, 11,12,13=J,Q,K)
        
    Returns:
        int: The optimal hand total
    """
    total = 0
    aces = 0
    
    for card in hand:
        if card == 1:  # Ace
            aces += 1
            total += 11
        elif card > 10:  # Face card
            total += 10
        else:
            total += card
    
    # Adjust for Aces if needed
    while total > 21 and aces > 0:
        total -= 10
        aces -= 1
    
    return total

def has_usable_ace(hand):
    """
    Determine if a hand has an Ace that can be counted as 11 without busting.
    
    Args:
        hand (list): List of card values (1=Ace, 11,12,13=J,Q,K)
        
    Returns:
        bool: True if the hand has a usable Ace, False otherwise
    """
    # Check if hand contains an Ace
    if 1 not in hand:
        return False
    
    # Calculate total without counting any Ace as 11
    non_ace_total = 0
    ace_count = 0
    
    for card in hand:
        if card == 1:
            ace_count += 1
            non_ace_total += 1
        elif card > 10:  # Face card
            non_ace_total += 10
        else:
            non_ace_total += card
    
    # Check if we can count one Ace as 11 without busting
    return non_ace_total <= 11
