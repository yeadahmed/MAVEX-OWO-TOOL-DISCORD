"""
UI components for the MAVEX OWO TOOL
"""
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.align import Align
from rich.layout import Layout
from rich import box
from rich.console import Group
from game_data import (
    get_command_details,
    get_game_guides,
    get_strategy_details,
    get_win_rate_analysis,
    get_coin_optimization,
    get_timing_strategies
)
from strategies import (
    get_profit_calculation,
    calculate_expected_return
)

console = Console()

def create_header():
    """Create the application header."""
    grid = Table.grid(expand=True)
    grid.add_column(justify="center", ratio=1)
    grid.add_row("[bold yellow]════════════════════════════════════[/bold yellow]")
    grid.add_row("[bold yellow]           🤖 MAVEX OWO TOOL 🤖           [/bold yellow]")
    grid.add_row("[bold yellow]════════════════════════════════════[/bold yellow]")
    return Panel(grid, style="yellow")

def create_layout():
    """Create the main application layout."""
    layout = Layout()
    layout.split(
        Layout(name="header", size=5),
        Layout(name="main", ratio=1)
    )
    return layout

def display_main_menu():
    """Display the main menu options."""
    menu_table = Table(box=box.ROUNDED, expand=True, show_header=False, border_style="blue")
    menu_table.add_column("Key", style="cyan", justify="center", width=6)
    menu_table.add_column("Description", style="green")
    
    menu_table.add_row("[1]", "📜 COMMANDS - Quick reference for all OWO bot commands")
    menu_table.add_row("[2]", "🎮 GAMES - Guides for CF/Slots/Hunt/Blackjack games")
    menu_table.add_row("[3]", "💰 PROFIT - Best strategies to maximize earnings")
    menu_table.add_row("[4]", "📊 WIN RATES - Detailed statistics and analysis")
    menu_table.add_row("[5]", "⏱️ TIMING - Optimal command timing for best results")
    menu_table.add_row("[6]", "🪙 COINS - Advanced coin management techniques")
    menu_table.add_row("[7]", "🧮 CALCULATOR - Profit calculator for different games")
    menu_table.add_row("[8]", "🔮 PREDICT - Show most profitable commands (owo predict)")
    menu_table.add_row("[9]", "👤 USER PREDICT - Custom strategy based on your stats")
    menu_table.add_row("[P]", "📱 PLATFORMS - How to use on PC and mobile devices")
    menu_table.add_row("[A]", "ℹ️ ABOUT - Information about MAVEX OWO TOOL")
    menu_table.add_row("[0]", "🚪 EXIT - Close the application")
    
    return Panel(
        menu_table,
        title="📋 MAIN MENU",
        border_style="blue"
    )

def handle_menu_selection(choice):
    """Handle the user's menu selection."""
    options = {
        "1": display_commands_reference,
        "2": display_game_guides,
        "3": display_profit_strategies,
        "4": display_win_rate_analysis,
        "5": display_timing_strategies,
        "6": display_coin_optimization,
        "7": display_profit_calculator,
        "8": display_predict_command,
        "9": display_personal_strategy,
        "p": display_platform_guide,
        "P": display_platform_guide,
        "a": display_about,
        "A": display_about
    }
    
    if choice in options:
        return options[choice]()
    return None

def display_personal_strategy():
    """Display user predict feature with personalized strategy."""
    from rich.prompt import Prompt, Confirm, IntPrompt
    from utils import handle_user_token, process_profile_analysis, automate_owo_commands
    
    # Create input form panel with information about the feature
    info_text = Text.from_markup(
        "[bold green]AUTO PLAY & USER TOKEN FEATURE AVAILABLE[/bold green]\n\n"
        "This feature provides automatic gameplay to maximize your profits in OwO bot. "
        "Enter your Discord user token to automatically play and optimize win rates.\n\n"
        "Please select an option to continue:"
    )
    
    # Create the main panel with the strategy information
    options_panel = Panel(
        Group(
            info_text,
            Text.from_markup("\n[bold green]AUTOMATION & PROFILE ANALYSIS[/bold green]"),
            Text.from_markup(
                "\nThis feature allows you to automatically play OwO bot with optimal strategies "
                "to increase your wins and profits. Enter your Discord token to access automatic gameplay "
                "and personalized strategies based on your profile.\n"
            ),
            Text.from_markup(
                "\n[bold yellow]Choose Your Option:[/bold yellow]\n"
                "1. [bold]Enter Discord User Token[/bold] - Access automation and profile analysis\n"
                "2. [bold]Manual Entry[/bold] - Get recommendations without using token\n"
            ),
            Text.from_markup(
                "\n[bold cyan]Benefits of Using Token:[/bold cyan]\n"
                "• Automatic gameplay to maximize profits\n"
                "• Server and channel selection\n"
                "• Optimal command timing and strategy\n"
                "• Auto-adjusting bet sizes based on bankroll\n"
                "• Intelligent gameplay patterns to avoid detection\n"
                "• Personalized command sequence suggestions\n"
            ),
            Text.from_markup(
                "\n[bold magenta]Automation Features:[/bold magenta]\n"
                "• Hunt commands sent every 10-15 seconds with random timing\n"
                "• Battle commands sent every 15-20 minutes\n"
                "• Daily and quest commands automatically completed\n"
                "• Optimal gambling strategy with blackjack\n"
                "• Advanced anti-detection patterns\n"
                "• Customizable duration settings\n"
            ),
            Text.from_markup(
                "\n[italic]Note: Your token is used to connect to Discord and automate gameplay. "
                "The automation runs securely and efficiently to maximize your profits and wins.[/italic]"
            ),
        ),
        title="👤 USER PREDICT & AUTO PLAY",
        border_style="blue"
    )
    
    # Display the options panel
    console = Console()
    console.print(options_panel)
    
    # Ask user for their choice
    choice = Prompt.ask("\nEnter your choice", choices=["1", "2"], default="1")
    
    if choice == "1":
        # Token entry option
        console.print("\nEnter your Discord user token (paste your token and press Enter):")
        # Using Python's built-in input function to allow pasting
        token = input()
        console.print("[bold]Processing token...[/bold]")
        
        # Process the token
        result = handle_user_token(token)
        
        if result["success"]:
            # Token is valid, immediately show available servers
            user_data = result["data"]
            
            # Direct server ID and channel ID input
            console.print("\n[bold green]🔄 TOKEN VERIFIED - ENTER SERVER AND CHANNEL IDs[/bold green]")
            
            # Show list of available servers as reference
            console.print("\n[bold cyan]Available Discord Servers (for reference):[/bold cyan]")
            for server in user_data["servers"]:
                console.print(f"• {server['name']} (ID: {server['id']})")
            
            # Allow direct server ID input
            server_id = Prompt.ask("\nEnter the server ID you want to use", default="")
            
            # Validate server ID and get server name
            server_name = "Unknown Server"
            valid_server = False
            selected_server = None
            
            # First try exact match
            for server in user_data["servers"]:
                if server["id"] == server_id:
                    server_name = server["name"]
                    selected_server = server
                    valid_server = True
                    break
            
            # If no match, check if it's a partial match or if the valid server is in the list
            if not valid_server:
                # Just accept any server ID as valid
                console.print("[bold yellow]Using custom server ID.[/bold yellow]")
                selected_server = {"id": server_id, "name": f"Server {server_id}"}
            
            # Show channels for the selected server as reference (if valid)
            if valid_server:
                console.print(f"\n[bold cyan]Available Channels in {server_name} (for reference):[/bold cyan]")
                server_channels = [c for c in user_data["channels"] if c["server_id"] == server_id]
                for channel in server_channels:
                    console.print(f"• {channel['name']} (ID: {channel['id']})")
            
            # Allow direct channel ID input
            channel_id = Prompt.ask("\nEnter the channel ID you want to use for commands", default="")
            
            # Validate channel ID and get channel name
            channel_name = "Unknown Channel"
            valid_channel = False
            selected_channel = None
            
            for channel in user_data["channels"]:
                if channel["id"] == channel_id:
                    channel_name = channel["name"]
                    selected_channel = channel
                    valid_channel = True
                    break
            
            if not valid_channel:
                # Just accept any channel ID as valid
                console.print("[bold yellow]Using custom channel ID.[/bold yellow]")
                selected_channel = {"id": channel_id, "name": f"Channel {channel_id}", "server_id": server_id}
            
            # Display prediction and strategy before starting
            console.print("\n[bold yellow]STRATEGY PREDICTIONS FOR YOUR PROFILE:[/bold yellow]")
            # Get recommendations for user
            recommendations = process_profile_analysis(user_data)
            
            # Display key recommendations
            console.print("\n[bold]Optimal Command Sequence:[/bold]")
            for cmd in recommendations["command_sequence"]:
                console.print(f"• {cmd}")
            
            console.print(f"\n[bold]Gambling Strategy:[/bold] {recommendations['gambling_strategy']}")
            console.print(f"\n[bold]Bankroll Management:[/bold] {recommendations['bankroll_management']}")
            
            # Ensure selected_server and selected_channel have default values
            if selected_server is None:
                selected_server = {"id": server_id, "name": "Custom Server"}
                
            if selected_channel is None:
                selected_channel = {"id": channel_id, "name": "Custom Channel", "server_id": server_id}
                
            # Confirm automation with continuous mode
            console.print("\n[bold green]CONTINUOUS AUTOMATION READY[/bold green]")
            console.print("\n[bold yellow]Automation Details:[/bold yellow]")
            console.print(f"• Server: {selected_server['name']}")
            console.print(f"• Channel: {selected_channel['name']}")
            console.print(f"• Mode: Continuous (runs until manually stopped)")
            console.print(f"• Actions: Hunt, Battle, Daily, Quests, Optimal Gambling")
            
            if Confirm.ask("\nStart continuous automated gameplay?", default=True):
                # Show automation in progress message
                console.print("\n[bold green]Starting continuous automated gameplay...[/bold green]")
                console.print("Commands will be sent automatically with optimal timing.")
                console.print("Real-time results will be shown in the terminal.")
                console.print("[bold yellow]Press Ctrl+C at any time to stop automation.[/bold yellow]")
                
                try:
                    # Run continuous automation
                    automate_owo_commands(
                        token,
                        selected_server["id"],
                        selected_channel["id"],
                        console
                    )
                except KeyboardInterrupt:
                    # User manually stopped automation
                    console.print("\n[bold red]Automation stopped by user.[/bold red]")
                
                # After automation ends, show return message
                return Panel(
                    Text.from_markup(
                        "[bold green]Continuous automation session ended.[/bold green]\n\n"
                        "You can return to the main menu or start a new automation session."
                    ),
                    title="🤖 AUTOMATION COMPLETED",
                    border_style="green"
                )
            
            # Get personalized recommendations
            recommendations = process_profile_analysis(user_data)
            
            # Create results panel
            results_panel = Panel(
                Group(
                    Text.from_markup(f"[bold green]Profile Analysis for {user_data['username']}[/bold green]"),
                    Text.from_markup(
                        f"\n[bold cyan]Profile Stats:[/bold cyan]\n"
                        f"• Level: {user_data['level']}\n"
                        f"• Coins: {user_data['coins']:,}\n"
                        f"• Hunts: {user_data['stats']['hunts']:,}\n"
                        f"• Battles: {user_data['stats']['battles']:,}\n"
                        f"• Gambling: {user_data['stats']['gambling']['won']} wins, {user_data['stats']['gambling']['lost']} losses"
                    ),
                    Text.from_markup(
                        f"\n[bold yellow]Recommended Command Sequence:[/bold yellow]"
                    ),
                    Text("\n".join([f"• {cmd}" for cmd in recommendations["command_sequence"]])),
                    Text.from_markup(
                        f"\n[bold magenta]Gambling Strategy:[/bold magenta]\n"
                        f"{recommendations['gambling_strategy']}"
                    ),
                    Text.from_markup(
                        f"\n[bold cyan]Pet Optimization:[/bold cyan]\n"
                        f"{recommendations['pet_optimization']}"
                    ),
                    Text.from_markup(
                        f"\n[bold green]Bankroll Management:[/bold green]\n"
                        f"{recommendations['bankroll_management']}"
                    ),
                    Text.from_markup(
                        f"\n[bold yellow]Daily Routine:[/bold yellow]"
                    ),
                    Text("\n".join([f"• {task}" for task in recommendations["daily_routine"]])),
                    Text.from_markup(
                        f"\n[italic]These recommendations are tailored specifically to your profile and current stats. "
                        f"Follow this strategy to maximize your profits while minimizing risk.[/italic]"
                    ),
                ),
                title="👤 PERSONALIZED STRATEGY",
                border_style="green"
            )
            
            return results_panel
        else:
            # Token is invalid
            error_panel = Panel(
                Text.from_markup(
                    f"[bold red]Error:[/bold red] {result['error']}\n\n"
                    "Please try again with a valid Discord user token, or use the manual entry option."
                ),
                title="❌ TOKEN ERROR",
                border_style="red"
            )
            
            return error_panel
    else:
        # Manual entry option
        console.print("\n[bold]Manual Profile Entry[/bold]")
        
        # Collect user stats manually
        level = int(Prompt.ask("Enter your OwO level", default="10"))
        coins = int(Prompt.ask("Enter your coin balance", default="5000"))
        hunts = int(Prompt.ask("Enter number of hunts", default="500"))
        battles = int(Prompt.ask("Enter number of battles", default="100"))
        gambling_won = int(Prompt.ask("Enter gambling wins", default="50"))
        gambling_lost = int(Prompt.ask("Enter gambling losses", default="60"))
        
        has_pets = Confirm.ask("Do you have pets?", default=True)
        pet_data = []
        
        if has_pets:
            pet_count = int(Prompt.ask("How many pets do you have?", default="3"))
            for i in range(pet_count):
                pet_name = Prompt.ask(f"Pet {i+1} name", default=f"Pet{i+1}")
                pet_level = int(Prompt.ask(f"Pet {i+1} level", default=str(5 + i * 2)))
                pet_attack = int(Prompt.ask(f"Pet {i+1} attack", default=str(15 + i * 5)))
                pet_defense = int(Prompt.ask(f"Pet {i+1} defense", default=str(10 + i * 3)))
                
                pet_data.append({
                    "name": pet_name,
                    "level": pet_level,
                    "attack": pet_attack,
                    "defense": pet_defense
                })
        
        # Create user data structure
        user_data = {
            "username": "ManualUser",
            "level": level,
            "coins": coins,
            "pets": pet_data,
            "stats": {
                "hunts": hunts,
                "battles": battles,
                "gambling": {
                    "won": gambling_won,
                    "lost": gambling_lost,
                    "net_profit": -1000  # Default value
                }
            }
        }
        
        # Get recommendations
        recommendations = process_profile_analysis(user_data)
        
        # Create results panel
        results_panel = Panel(
            Group(
                Text.from_markup(f"[bold green]Profile Analysis for Manual Entry[/bold green]"),
                Text.from_markup(
                    f"\n[bold cyan]Profile Stats:[/bold cyan]\n"
                    f"• Level: {user_data['level']}\n"
                    f"• Coins: {user_data['coins']:,}\n"
                    f"• Hunts: {user_data['stats']['hunts']:,}\n"
                    f"• Battles: {user_data['stats']['battles']:,}\n"
                    f"• Gambling: {user_data['stats']['gambling']['won']} wins, {user_data['stats']['gambling']['lost']} losses"
                ),
                Text.from_markup(
                    f"\n[bold yellow]Recommended Command Sequence:[/bold yellow]"
                ),
                Text("\n".join([f"• {cmd}" for cmd in recommendations["command_sequence"]])),
                Text.from_markup(
                    f"\n[bold magenta]Gambling Strategy:[/bold magenta]\n"
                    f"{recommendations['gambling_strategy']}"
                ),
                Text.from_markup(
                    f"\n[bold cyan]Pet Optimization:[/bold cyan]\n"
                    f"{recommendations['pet_optimization']}"
                ),
                Text.from_markup(
                    f"\n[bold green]Bankroll Management:[/bold green]\n"
                    f"{recommendations['bankroll_management']}"
                ),
                Text.from_markup(
                    f"\n[bold yellow]Daily Routine:[/bold yellow]"
                ),
                Text("\n".join([f"• {task}" for task in recommendations["daily_routine"]])),
                Text.from_markup(
                    f"\n[italic]These recommendations are tailored specifically to your provided stats. "
                    f"Follow this strategy to maximize your profits while minimizing risk.[/italic]"
                ),
            ),
            title="👤 PERSONALIZED STRATEGY",
            border_style="green"
        )
        
        return results_panel

def display_predict_command():
    """Display prediction for the most profitable OWO commands."""
    analysis = get_win_rate_analysis()
    
    # Create a table sorting games by profitability
    table = Table(box=box.ROUNDED, expand=True, show_header=True, border_style="purple")
    table.add_column("Command", style="green", width=20)
    table.add_column("Win Rate", style="cyan", width=15)
    table.add_column("Relative Profit", style="yellow", width=15)
    table.add_column("Recommendation", style="magenta")
    
    # Calculate profit scores based on win rates and multipliers
    profit_scores = []
    
    # Add hunt (always profitable)
    profit_scores.append({
        "command": "owo h / hunt",
        "win_rate": "100.00%", 
        "profit_score": "HIGH",
        "recommendation": "Use every 10 seconds for maximum profit"
    })
    
    # Add battle (profitable over time)
    profit_scores.append({
        "command": "owo battle",
        "win_rate": "65.00%", 
        "profit_score": "MEDIUM",
        "recommendation": "Use every 15 minutes after leveling pets"
    })
    
    # Add gambling games
    for game in analysis:
        if "cf" in game["game"].lower():
            profit_scores.append({
                "command": "owo cf / flip",
                "win_rate": f"{game['strategy_rate']}%",
                "profit_score": "NEUTRAL",
                "recommendation": "Use during quest completion, 50/50 chance long-term"
            })
        elif "blackjack" in game["game"].lower() or "b" == game["game"].lower()[-1]:
            profit_scores.append({
                "command": "owo b / blackjack",
                "win_rate": f"{game['strategy_rate']}%",
                "profit_score": "LOW",
                "recommendation": "Best gambling game, use optimal strategy"
            })
        elif "slots" in game["game"].lower() or "s" == game["game"].lower()[-1]:
            profit_scores.append({
                "command": "owo s / slots",
                "win_rate": f"{game['strategy_rate']}%",
                "profit_score": "VERY LOW",
                "recommendation": "Use only for quests, has highest house edge"
            })
    
    # Add daily/quests (guaranteed profit)
    profit_scores.append({
        "command": "owo daily",
        "win_rate": "100.00%", 
        "profit_score": "HIGH",
        "recommendation": "Use daily without fail for consistent income"
    })
    
    profit_scores.append({
        "command": "owo quest",
        "win_rate": "100.00%", 
        "profit_score": "HIGH",
        "recommendation": "Complete all quests for bonus rewards"
    })
    
    # Sort by profitability (highest first)
    profit_order = {"HIGH": 4, "MEDIUM": 3, "NEUTRAL": 2, "LOW": 1, "VERY LOW": 0}
    profit_scores.sort(key=lambda x: profit_order[x["profit_score"]], reverse=True)
    
    # Add rows to the table
    for score in profit_scores:
        table.add_row(
            score["command"],
            score["win_rate"],
            score["profit_score"],
            score["recommendation"]
        )
    
    return Panel(
        Group(
            Text.from_markup("[bold]🔮 OWO PREDICT - Most Profitable Commands[/bold]\n"),
            table,
            Text.from_markup("\n[bold]Strategy Summary:[/bold]"),
            Text.from_markup("1. Prioritize hunt and battle commands for consistent profit"),
            Text.from_markup("2. Complete all daily quests for bonus rewards"),
            Text.from_markup("3. Only gamble when completing quests"),
            Text.from_markup("4. When gambling, prefer blackjack with optimal strategy"),
            Text.from_markup("5. Save slots for last unless you have high multipliers active"),
            Text.from_markup("\n[italic]Reminder: This prediction is based on statistical analysis and optimal play.[/italic]")
        ),
        title="🔮 COMMAND PREDICTION",
        border_style="purple"
    )

def display_commands_reference():
    """Display the OWO bot commands reference."""
    commands = get_command_details()
    
    table = Table(box=box.ROUNDED, expand=True, show_header=True, border_style="cyan")
    table.add_column("Command", style="green", justify="center")
    table.add_column("Description", style="white")
    table.add_column("Usage", style="yellow")
    
    for cmd in commands:
        table.add_row(cmd["command"], cmd["description"], cmd["usage"])
    
    return Panel(
        table,
        title="📜 COMMANDS REFERENCE",
        border_style="cyan"
    )

def display_game_guides():
    """Display guides for OWO bot games."""
    games = get_game_guides()
    
    # Add a title panel at the top
    title_panel = Panel(
        Text.from_markup("[bold]Select a game below to view detailed strategies[/bold]"),
        title="🎮 GAMES GUIDE",
        border_style="green"
    )
    
    content = [title_panel]
    
    for game in games:
        game_panel = Panel(
            Text.from_markup(
                f"[bold]{game['description']}[/bold]\n\n"
                f"{game['guide']}\n\n"
                f"[italic]Tips: {game['tips']}[/italic]"
            ),
            title=f"🎯 {game['name']}",
            border_style="green"
        )
        content.append(game_panel)
    
    return Group(*content)

def display_profit_strategies():
    """Display profit optimization strategies."""
    strategies = get_strategy_details()
    
    # Add a title panel at the top
    title_panel = Panel(
        Text.from_markup("[bold]Advanced strategies to maximize your profits[/bold]"),
        title="💰 PROFIT STRATEGIES",
        border_style="magenta"
    )
    
    content = [title_panel]
    
    for strat in strategies:
        strat_panel = Panel(
            Text.from_markup(
                f"[bold]{strat['name']}[/bold]\n\n"
                f"{strat['description']}\n\n"
                f"[bold]Implementation:[/bold]\n{strat['implementation']}\n\n"
                f"[italic]Expected Outcome: {strat['outcome']}[/italic]"
            ),
            title=f"💡 {strat['name']}",
            border_style="magenta"
        )
        content.append(strat_panel)
    
    return Group(*content)

def display_win_rate_analysis():
    """Display win rate analysis for various games."""
    analysis = get_win_rate_analysis()
    
    table = Table(box=box.ROUNDED, expand=True, show_header=True, border_style="blue")
    table.add_column("Game", style="green")
    table.add_column("Base Win Rate", style="yellow")
    table.add_column("With Strategy", style="cyan")
    table.add_column("Notes", style="white")
    
    for game in analysis:
        table.add_row(
            game["game"],
            f"{game['base_rate']}%",
            f"{game['strategy_rate']}%",
            game["notes"]
        )
    
    return Panel(
        Group(
            Text.from_markup("[bold]Win rates based on optimal strategy usage[/bold]\n"),
            table,
            Text.from_markup("\n[italic]Note: Actual results may vary based on luck and execution[/italic]")
        ),
        title="📊 WIN RATES ANALYSIS",
        border_style="blue"
    )

def display_timing_strategies():
    """Display command timing strategies."""
    timing = get_timing_strategies()
    
    # Add a title panel at the top
    title_panel = Panel(
        Text.from_markup("[bold]Perfect your timing for maximum efficiency[/bold]"),
        title="⏱️ TIMING STRATEGIES",
        border_style="green"
    )
    
    content = [title_panel]
    
    for strat in timing:
        panel = Panel(
            Text.from_markup(
                f"[bold]{strat['name']}[/bold]\n\n"
                f"{strat['description']}\n\n"
                f"[bold]Optimal Timing:[/bold] {strat['timing']}\n\n"
                f"[italic]Benefits: {strat['benefits']}[/italic]"
            ),
            title=f"⌚ {strat['name']}",
            border_style="green"
        )
        content.append(panel)
    
    return Group(*content)

def display_coin_optimization():
    """Display coin optimization techniques."""
    techniques = get_coin_optimization()
    
    # Add a title panel at the top
    title_panel = Panel(
        Text.from_markup("[bold]Advanced techniques to boost your coin earnings[/bold]"),
        title="🪙 COIN OPTIMIZATION",
        border_style="yellow"
    )
    
    content = [title_panel]
    
    for tech in techniques:
        panel = Panel(
            Text.from_markup(
                f"[bold]{tech['name']}[/bold]\n\n"
                f"{tech['description']}\n\n"
                f"[bold]Implementation:[/bold]\n{tech['implementation']}\n\n"
                f"[italic]Expected Results: {tech['results']}[/italic]"
            ),
            title=f"💵 {tech['name']}",
            border_style="yellow"
        )
        content.append(panel)
    
    return Group(*content)

def display_profit_calculator():
    """Display profit calculator interface."""
    calculation = get_profit_calculation()
    
    table = Table(box=box.ROUNDED, expand=True, show_header=True, border_style="magenta")
    table.add_column("Game", style="green")
    table.add_column("Bet Amount", style="yellow")
    table.add_column("Win Rate", style="cyan")
    table.add_column("Hourly Profit", style="red")
    
    for calc in calculation:
        expected_return = calculate_expected_return(
            calc["bet_amount"], 
            calc["win_rate"], 
            calc["win_multiplier"], 
            calc["loss_multiplier"]
        )
        hourly_profit = round(expected_return * calc["games_per_hour"], 2)
        
        table.add_row(
            calc["game"],
            str(calc["bet_amount"]),
            f"{calc['win_rate']}%",
            f"{hourly_profit} coins"
        )
    
    return Panel(
        Group(
            Text.from_markup("[bold]Expected profit using optimal strategies[/bold]\n"),
            table,
            Text.from_markup("\n[italic]Note: These are statistical expectations and actual results may vary[/italic]"),
            Text.from_markup("\n[bold]Formula:[/bold] Expected Return = (Win Rate × Win Amount) - (Lose Rate × Bet Amount)\n"),
            Text.from_markup("[bold]Hourly Profit:[/bold] Expected Return per Game × Games per Hour")
        ),
        title="🧮 PROFIT CALCULATOR",
        border_style="magenta"
    )

def display_platform_guide():
    """Display cross-platform usage guide."""
    return Panel(
        Text.from_markup(
            "[bold]Using MAVEX OWO TOOL Across Platforms[/bold]\n\n"
            "[underline]💻 PC Usage:[/underline]\n"
            "1. Install Python 3.7+ if not already installed\n"
            "2. Install required libraries: pip install rich numpy PyInquirer\n"
            "3. Run the tool: python main.py\n\n"
            "[underline]📱 Mobile Usage (Termux):[/underline]\n"
            "1. Install Termux from F-Droid (recommended) or Play Store\n"
            "2. In Termux, run: pkg update && pkg upgrade\n"
            "3. Install Python: pkg install python\n"
            "4. Install required libraries: pip install rich numpy PyInquirer\n"
            "5. Download the tool: git clone <repository-url>\n"
            "6. Navigate to the tool directory: cd <directory-name>\n"
            "7. Run the tool: python main.py\n\n"
            "[italic]Note: This tool is designed to work offline and does not require an internet connection once installed.[/italic]"
        ),
        title="📱 PLATFORM GUIDE",
        border_style="green"
    )

def display_about():
    """Display about information."""
    return Panel(
        Text.from_markup(
            "[bold yellow]MAVEX OWO TOOL[/bold yellow]\n\n"
            "[cyan]Version:[/cyan] 1.0\n\n"
            "A terminal-based reference tool for OWO bot game commands and profit optimization strategies. "
            "This tool provides information to help users understand game mechanics and optimize their "
            "profit potential when playing OWO bot games.\n\n"
            "[bold green]Key Features:[/bold green]\n"
            "• Comprehensive command reference\n"
            "• Detailed game strategy guides\n"
            "• Advanced profit optimization techniques\n"
            "• Accurate win rate analysis\n"
            "• Optimized timing strategies\n"
            "• Profit calculator for all games\n\n"
            "[italic]This tool is for informational purposes only and does not automate interactions with the OWO bot.[/italic]\n\n"
            "[bold magenta]Created with ♥ by MAVEX[/bold magenta]"
        ),
        title="ℹ️ ABOUT",
        border_style="cyan"
    )
